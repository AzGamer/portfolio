#!/bin/bash

# Exécuter le script qui formate le tableau
bash script_tableau.sh

# Exécuter le script qui télécharge les drapeaux dans le bon format
bash script_drapeaux.sh